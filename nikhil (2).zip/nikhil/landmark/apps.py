from django.apps import AppConfig


class LandmarkConfig(AppConfig):
    name = 'landmark'
