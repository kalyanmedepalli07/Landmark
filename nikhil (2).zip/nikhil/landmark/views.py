from django.shortcuts import render
# Create your views here.
from tensorflow.keras.preprocessing.image  import ImageDataGenerator,load_img
from PIL import Image,ImageOps
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
import tensorflow as tf
import numpy as np
import copy
import os
import tensorflow_hub as hub
from tensorflow.keras.preprocessing import image
from tensorflow.keras.preprocessing.image import img_to_array
from scipy.spatial import cKDTree
from skimage.feature import plot_matches
from skimage.measure import ransac
from skimage.transform import AffineTransform
import matplotlib.pyplot as plt
import pandas as pd

img_height,img_width =(224,224)
batch_size =32

train_data_dir = "F:/Major Project/dataset/processed_data1/train"
test_data_dir = "F:/Major Project/dataset/processed_data1/test"
val_data_dir = "F:/Major Project/dataset/processed_data1/val"

p ='F:/Major Project/Major_dataset/Major_dataset'
li4 = os.listdir(p)

delf = hub.load('https://tfhub.dev/google/delf/1').signatures['default']
data1 = pd.read_csv('F:/Major Project/dataframe.csv')


def home(request):
    with open('F:/surya/nikhil/landmark/landmarks_names.txt', 'r+') as files:
        data = files.readline()
        data = data.split(',')
    if request.method=="POST":
        f = request.FILES['file']
        file_object=str(f)
        print(type(f))
        with open('image1.jpeg', 'wb+') as f1:
            for chunk in f.chunks():
                f1.write(chunk)
        if request.POST.get('label'):
          label,data = predict_landmark('image1.jpeg')
          return render(request,'detect.html',{'data':data,'label':label})
        elif request.POST.get('cluster'):
          cluster_images('image1.jpeg')
          return render(request,'cluster.html')

        
    files.close()
    return render(request,'home.html',{'data':data})


def predict_landmark(name):
    image = Image.open(name)
    image = image.resize((224,224))
    im = np.expand_dims(image, axis=0)
    model = tf.keras.models.load_model('F:/Major Project/dataset/processed_data1/ResNet50_Fl.h5')
    lis = model.predict(im)
    li = lis.tolist()
    names=list(os.listdir(train_data_dir))
    # with open('F:/surya/nikhil/landmark/landmarks_names.txt','r+') as f1:
    #     names = list(f1.readline().split('+'))
    names.sort()
    li1 = copy.deepcopy(li[0])
    li1.sort(reverse=True)
    names_list=[]
    print(len(names))
    data=[]
    names_list.append(names[li[0].index(li1[0])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[0]))
    names_list.append(names[li[0].index(li1[1])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[1]))
    names_list.append(names[li[0].index(li1[2])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[2]))
    names_list.append(names[li[0].index(li1[3])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[3]))
    names_list.append(names[li[0].index(li1[4])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[4]))
    names_list.append(names[li[0].index(li1[5])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[5]))
    names_list.append(names[li[0].index(li1[6])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[6]))
    names_list.append(names[li[0].index(li1[7])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[7]))
    names_list.append(names[li[0].index(li1[8])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[8]))
    names_list.append(names[li[0].index(li1[9])].strip())
    data.append(names_list[-1]+"---------->"+str(li1[9]))
    print(data)
    images=[]
    for j in names_list:
        fil = os.listdir(train_data_dir+'/'+j)
        for k in fil:
          images.append(train_data_dir+'/'+j+'/'+k)
    print(names_list)
    out = run_delf1(names_list,image)
    print(out)
    return out,data

def match_images1(image1, image2, result1, result2):
  distance_threshold = 0.8
  num_features_1 = result1['locations'].shape[0]
  
  num_features_2 = result2['locations'].shape[0]

  # Find nearest-neighbor matches using a KD tree.
  d1_tree = cKDTree(result1['descriptors'])
  _, indices = d1_tree.query(
      result2['descriptors'],
      distance_upper_bound=distance_threshold)

  # Select feature locations for putative matches.
  locations_2_to_use = np.array([
      result2['locations'][i,]
      for i in range(num_features_2)
      if indices[i] != num_features_1
  ])
  locations_1_to_use = np.array([
      result1['locations'][indices[i],]
      for i in range(num_features_2)
      if indices[i] != num_features_1
  ])
  # print(locations_1_to_use,locations_2_to_use)
  # Perform geometric verification using RANSAC.
  if len(locations_1_to_use)>2:
    _, inliers = ransac(
        (locations_1_to_use, locations_2_to_use),
        AffineTransform,
        min_samples=2,
        residual_threshold=20,
        max_trials=1000) 
    if not isinstance(inliers, type(None)):
      lis= [len(inliers),image1,image2,locations_1_to_use,locations_2_to_use,inliers]
      return lis
  return []

def delf_tri1(image):
  np_image = np.array(image)
  float_image = tf.image.convert_image_dtype(np_image,tf.float32)

  return delf(image = float_image,
              score_threshold = tf.constant(100.0),
              image_scales = tf.constant([0.25,0.3536,0.5,0.7061,1.0,1.4142,2.0]),
              max_feature_num= tf.constant(1000))

def run_delf1(names_list,image):

  predict_image = image
  predict_image = ImageOps.fit(predict_image,(256,256),Image.ANTIALIAS)
  predict_result = delf_tri1(predict_image)
  maximum_pro = 0
  label =""
  for j in names_list:
    fil = os.listdir(train_data_dir+'/'+j)
    i=0
    for k in fil:
      i+=1
      im = train_data_dir+'/'+j+'/'+k
      sample_image  = Image.open(im)
      sample_image = ImageOps.fit(sample_image,(256,256),Image.ANTIALIAS)
      s_r = delf_tri1(sample_image)
      # print(sample_result,predict_result,sep="IBONPB OBP: ")
      ou = match_images1(sample_image,predict_image,s_r,predict_result)
      if len(ou)!=0:
        i1,i2,l1,l2,inlin=ou[1],ou[2],ou[3],ou[4],ou[5]
        if maximum_pro<ou[0]:
          maximum_pro = ou[0]
          label  = j
          a=i1
          b=i2
          c=l1
          d=l2
          e=inlin
        if i==1:
            break
  _, ax = plt.subplots()
  inlier_idxs = np.nonzero(e)[0]
  plot_matches(
      ax,
      a,
      b,
      c,
      d,
      np.column_stack((inlier_idxs, inlier_idxs)),
      matches_color='g')
  ax.axis('off')
  ax.set_title('DELF Matches')
  plt.savefig("./landmark/static/plot_matches.png")
  return label





def cluster_images(name):
  model = tf.keras.models.load_model('F:/Major Project/dataset/processed_data1/ResNet50_Fl.h5')
  labels_list=[]
  image = Image.open(name)
  image = image.resize((224,224))
  im = np.expand_dims(image, axis=0)
  lis = model.predict(im)
  li = lis.tolist()
  names = os.listdir(test_data_dir)
  names.sort()
  li1 = copy.deepcopy(li[0])
  li1.sort(reverse=True)
  final_label = li[0].index(li1[0])
  labels_list.append(li[0].index(li1[0]))
  labels_list.append(li[0].index(li1[1]))
  labels_list.append(li[0].index(li1[2]))
  labels_list.append(li[0].index(li1[3]))
  labels_list.append(li[0].index(li1[4]))
  labels_list.append(li[0].index(li1[5]))
  labels_list.append(li[0].index(li1[6]))
  labels_list.append(li[0].index(li1[7]))
  labels_list.append(li[0].index(li1[8]))
  labels_list.append(li[0].index(li1[9]))
  output_files=[]
  for i in labels_list:
    output_files.extend(list(data1[data1['label']==i]['image'][:5]))
  output_list =run_delf2(output_files,image)
  labels1=[]
  for i in output_list:
    print(i)
    if i[1]!=[]:
      labels1.append(i)
  labels=sorted(labels1,key=lambda x:x[1],reverse=True)
  output_files = labels
  c=0
  # print(output_files)
  # p = 'F:/Major Project/dataset/processed_data1/train/India Gate'
  # output_files = os.listdir('F:/Major Project/dataset/processed_data1/train/India Gate')
  print(output_files)
  w = 10
  h = 10
  fig = plt.figure(figsize=(8, 8))
  columns = 2
  rows = 2
  for i in range(1,5):
    img = Image.open(p+"/"+output_files[i][0])
    fig.add_subplot(rows,columns,i)
    plt.imshow(img)
  plt.savefig("./landmark/static/cluster_images.png")
  
  # output_data=[]
  # for i in range(9):
  #   img = Image.open(p+'/'+output_files[i][0])
  #   print(output_files[i][0])
  #   img.save("./landmark/static/{0}.png".format(i))
  #   output_data.append(i)
  # #   try:
  #     plt.subplot(330 + 1 + c)
  #     c+=1
  #     name = p+'/'+i
  #     print(name)
  #     img = Image.open(name)
  #     plt.imshow(img)
  #   except:
  #     print("ISNINSI")
  #     pass
  # plt.savefig("./landmark/static/cluster_images.png")


def match_images2(image1, image2, result1, result2):
  distance_threshold = 0.8
  num_features_1 = result1['locations'].shape[0]
  
  num_features_2 = result2['locations'].shape[0]

  # Find nearest-neighbor matches using a KD tree.
  d1_tree = cKDTree(result1['descriptors'])
  _, indices = d1_tree.query(
      result2['descriptors'],
      distance_upper_bound=distance_threshold)

  # Select feature locations for putative matches.
  locations_2_to_use = np.array([
      result2['locations'][i,]
      for i in range(num_features_2)
      if indices[i] != num_features_1
  ])
  locations_1_to_use = np.array([
      result1['locations'][indices[i],]
      for i in range(num_features_2)
      if indices[i] != num_features_1
  ])
  # print(locations_1_to_use,locations_2_to_use)
  # Perform geometric verification using RANSAC.
  if len(locations_1_to_use)>2:
    _, inliers = ransac(
        (locations_1_to_use, locations_2_to_use),
        AffineTransform,
        min_samples=2,
        residual_threshold=20,
        max_trials=1000) 
    if not isinstance(inliers, type(None)):
      lis= len(inliers)
      return lis
  return []

def delf_tri2(image):
  np_image = np.array(image)
  float_image = tf.image.convert_image_dtype(np_image,tf.float32)

  return delf(image = float_image,
              score_threshold = tf.constant(100.0),
              image_scales = tf.constant([0.25,0.3536,0.5,0.7061,1.0,1.4142,2.0]),
              max_feature_num= tf.constant(1000))

def run_delf2(output_files,image):

  predict_image = image
  predict_image = ImageOps.fit(predict_image,(256,256),Image.ANTIALIAS)
  predict_result = delf_tri2(predict_image)
  maximum_pro = 0
  label =""
  list1=[]
  for i in output_files:
    try:
      image=load_img(p+'/'+i)
      image = ImageOps.fit(image,(256,256),Image.ANTIALIAS)
      s_r = delf_tri2(image)
      ou = match_images2(image,predict_image,s_r,predict_result)
      list1.append([i,ou])
    except:
      pass
  return list1